 ALTER SEQUENCE hibernate_sequence RESTART WITH 10001;

 TRUNCATE TABLE owner CASCADE;
 TRUNCATE TABLE app_user CASCADE;
 TRUNCATE TABLE role CASCADE;
 TRUNCATE TABLE user_role CASCADE;

 INSERT INTO owner (id, cnpj, corporate_name,  phone_number, logo, name) values (101,'','JSetup Developer', '997608620','','JSetup Developer');

 INSERT INTO role( id, id_owner, authority, description)  VALUES (101, 101, 'ROLE_USER', 'Usuário do sistema');
 INSERT INTO app_user( id, id_owner, enable, image, name, password, username, email) VALUES (101, 101, true, '', 'Usuário JSetup Comum', '$2a$10$teJrCEnsxNT49ZpXU7n22O27aCGbVYYe/RG6/XxdWPJbOLZubLIi2', 'jsetup', 'contato@jsetup.com');
 INSERT INTO user_role(id_role, id_user) values (101, 101);

TRUNCATE TABLE LINGUAGEM CASCADE;
INSERT INTO LINGUAGEM 	( id, id_owner
			,NOME
			,TIPO
			)values(1, 101
			, 'nome linguagem1'
			, 'tipo linguagem1'
			);
INSERT INTO LINGUAGEM 	( id, id_owner
			,NOME
			,TIPO
			)values(2, 101
			, 'nome linguagem2'
			, 'tipo linguagem2'
			);
INSERT INTO LINGUAGEM 	( id, id_owner
			,NOME
			,TIPO
			)values(3, 101
			, 'nome linguagem3'
			, 'tipo linguagem3'
			);
INSERT INTO LINGUAGEM 	( id, id_owner
			,NOME
			,TIPO
			)values(4, 101
			, 'nome linguagem4'
			, 'tipo linguagem4'
			);
INSERT INTO LINGUAGEM 	( id, id_owner
			,NOME
			,TIPO
			)values(5, 101
			, 'nome linguagem5'
			, 'tipo linguagem5'
			);
