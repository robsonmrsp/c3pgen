		
ALTER SEQUENCE hibernate_sequence RESTART WITH 1001;
TRUNCATE TABLE LINGUAGEM CASCADE;
INSERT INTO LINGUAGEM 	( id
			,NOME
			,TIPO
			)values(1
			, 'nome linguagem1'
			, 'tipo linguagem1'
			);
			
INSERT INTO LINGUAGEM 	( id
			,NOME
			,TIPO
			)values(2
			, 'nome linguagem2'
			, 'tipo linguagem2'
			);
			
INSERT INTO LINGUAGEM 	( id
			,NOME
			,TIPO
			)values(3
			, 'nome linguagem3'
			, 'tipo linguagem3'
			);
			
INSERT INTO LINGUAGEM 	( id
			,NOME
			,TIPO
			)values(4
			, 'nome linguagem4'
			, 'tipo linguagem4'
			);
			
INSERT INTO LINGUAGEM 	( id
			,NOME
			,TIPO
			)values(5
			, 'nome linguagem5'
			, 'tipo linguagem5'
			);
			

ALTER SEQUENCE hibernate_sequence RESTART WITH 2001;
TRUNCATE TABLE DEPENDENTE CASCADE;
INSERT INTO DEPENDENTE 	( id
			,NOME
			)values(1
			, 'nome dependente1'
			);
			
INSERT INTO DEPENDENTE 	( id
			,NOME
			)values(2
			, 'nome dependente2'
			);
			
INSERT INTO DEPENDENTE 	( id
			,NOME
			)values(3
			, 'nome dependente3'
			);
			
INSERT INTO DEPENDENTE 	( id
			,NOME
			)values(4
			, 'nome dependente4'
			);
			
INSERT INTO DEPENDENTE 	( id
			,NOME
			)values(5
			, 'nome dependente5'
			);
			

ALTER SEQUENCE hibernate_sequence RESTART WITH 3001;
TRUNCATE TABLE FILME CASCADE;
INSERT INTO FILME 	( id
			,TITULO_ORIGINAL
			,POSTER
			,SINOPSE
			,TITULO
			,DIRETOR
			)values(1
			, 'tituloOriginal filme1'
			, 'poster filme1'
			, 'sinopse filme1'
			, 'titulo filme1'
			, 'diretor filme1'
			);
			
INSERT INTO FILME 	( id
			,TITULO_ORIGINAL
			,POSTER
			,SINOPSE
			,TITULO
			,DIRETOR
			)values(2
			, 'tituloOriginal filme2'
			, 'poster filme2'
			, 'sinopse filme2'
			, 'titulo filme2'
			, 'diretor filme2'
			);
			
INSERT INTO FILME 	( id
			,TITULO_ORIGINAL
			,POSTER
			,SINOPSE
			,TITULO
			,DIRETOR
			)values(3
			, 'tituloOriginal filme3'
			, 'poster filme3'
			, 'sinopse filme3'
			, 'titulo filme3'
			, 'diretor filme3'
			);
			
INSERT INTO FILME 	( id
			,TITULO_ORIGINAL
			,POSTER
			,SINOPSE
			,TITULO
			,DIRETOR
			)values(4
			, 'tituloOriginal filme4'
			, 'poster filme4'
			, 'sinopse filme4'
			, 'titulo filme4'
			, 'diretor filme4'
			);
			
INSERT INTO FILME 	( id
			,TITULO_ORIGINAL
			,POSTER
			,SINOPSE
			,TITULO
			,DIRETOR
			)values(5
			, 'tituloOriginal filme5'
			, 'poster filme5'
			, 'sinopse filme5'
			, 'titulo filme5'
			, 'diretor filme5'
			);
			

ALTER SEQUENCE hibernate_sequence RESTART WITH 4001;
TRUNCATE TABLE CLASSIFICACAO CASCADE;
INSERT INTO CLASSIFICACAO 	( id
			,NOME
			,DESCRICAO
			)values(1
			, 'nome classificacao1'
			, 'descricao classificacao1'
			);
			
INSERT INTO CLASSIFICACAO 	( id
			,NOME
			,DESCRICAO
			)values(2
			, 'nome classificacao2'
			, 'descricao classificacao2'
			);
			
INSERT INTO CLASSIFICACAO 	( id
			,NOME
			,DESCRICAO
			)values(3
			, 'nome classificacao3'
			, 'descricao classificacao3'
			);
			
INSERT INTO CLASSIFICACAO 	( id
			,NOME
			,DESCRICAO
			)values(4
			, 'nome classificacao4'
			, 'descricao classificacao4'
			);
			
INSERT INTO CLASSIFICACAO 	( id
			,NOME
			,DESCRICAO
			)values(5
			, 'nome classificacao5'
			, 'descricao classificacao5'
			);
			

ALTER SEQUENCE hibernate_sequence RESTART WITH 5001;
TRUNCATE TABLE ATOR CASCADE;
INSERT INTO ATOR 	( id
			,BIOGRAFIA
			,NOME
			,FOTO
			)values(1
			, 'biografia ator1'
			, 'nome ator1'
			, 'foto ator1'
			);
			
INSERT INTO ATOR 	( id
			,BIOGRAFIA
			,NOME
			,FOTO
			)values(2
			, 'biografia ator2'
			, 'nome ator2'
			, 'foto ator2'
			);
			
INSERT INTO ATOR 	( id
			,BIOGRAFIA
			,NOME
			,FOTO
			)values(3
			, 'biografia ator3'
			, 'nome ator3'
			, 'foto ator3'
			);
			
INSERT INTO ATOR 	( id
			,BIOGRAFIA
			,NOME
			,FOTO
			)values(4
			, 'biografia ator4'
			, 'nome ator4'
			, 'foto ator4'
			);
			
INSERT INTO ATOR 	( id
			,BIOGRAFIA
			,NOME
			,FOTO
			)values(5
			, 'biografia ator5'
			, 'nome ator5'
			, 'foto ator5'
			);
			

ALTER SEQUENCE hibernate_sequence RESTART WITH 6001;
TRUNCATE TABLE GENERO CASCADE;
INSERT INTO GENERO 	( id
			,NOME
			,DESCRICAO
			)values(1
			, 'nome genero1'
			, 'descricao genero1'
			);
			
INSERT INTO GENERO 	( id
			,NOME
			,DESCRICAO
			)values(2
			, 'nome genero2'
			, 'descricao genero2'
			);
			
INSERT INTO GENERO 	( id
			,NOME
			,DESCRICAO
			)values(3
			, 'nome genero3'
			, 'descricao genero3'
			);
			
INSERT INTO GENERO 	( id
			,NOME
			,DESCRICAO
			)values(4
			, 'nome genero4'
			, 'descricao genero4'
			);
			
INSERT INTO GENERO 	( id
			,NOME
			,DESCRICAO
			)values(5
			, 'nome genero5'
			, 'descricao genero5'
			);
			

ALTER SEQUENCE hibernate_sequence RESTART WITH 7001;
TRUNCATE TABLE ASSINANTE CASCADE;
INSERT INTO ASSINANTE 	( id
			,TELEFONE
			,CPF
			,NOME
			,OBSERVACAO
			,FOTO
			,CELULAR
			,RG
			)values(1
			, 'telefone assinante1'
			, 'cpf assinante1'
			, 'nome assinante1'
			, 'observacao assinante1'
			, 'foto assinante1'
			, 'celular assinante1'
			, 'rg assinante1'
			);
			
INSERT INTO ASSINANTE 	( id
			,TELEFONE
			,CPF
			,NOME
			,OBSERVACAO
			,FOTO
			,CELULAR
			,RG
			)values(2
			, 'telefone assinante2'
			, 'cpf assinante2'
			, 'nome assinante2'
			, 'observacao assinante2'
			, 'foto assinante2'
			, 'celular assinante2'
			, 'rg assinante2'
			);
			
INSERT INTO ASSINANTE 	( id
			,TELEFONE
			,CPF
			,NOME
			,OBSERVACAO
			,FOTO
			,CELULAR
			,RG
			)values(3
			, 'telefone assinante3'
			, 'cpf assinante3'
			, 'nome assinante3'
			, 'observacao assinante3'
			, 'foto assinante3'
			, 'celular assinante3'
			, 'rg assinante3'
			);
			
INSERT INTO ASSINANTE 	( id
			,TELEFONE
			,CPF
			,NOME
			,OBSERVACAO
			,FOTO
			,CELULAR
			,RG
			)values(4
			, 'telefone assinante4'
			, 'cpf assinante4'
			, 'nome assinante4'
			, 'observacao assinante4'
			, 'foto assinante4'
			, 'celular assinante4'
			, 'rg assinante4'
			);
			
INSERT INTO ASSINANTE 	( id
			,TELEFONE
			,CPF
			,NOME
			,OBSERVACAO
			,FOTO
			,CELULAR
			,RG
			)values(5
			, 'telefone assinante5'
			, 'cpf assinante5'
			, 'nome assinante5'
			, 'observacao assinante5'
			, 'foto assinante5'
			, 'celular assinante5'
			, 'rg assinante5'
			);
			

ALTER SEQUENCE hibernate_sequence RESTART WITH 8001;
TRUNCATE TABLE APP_USER CASCADE;
INSERT INTO APP_USER 	( id
			,NAME
			,USERNAME
			,EMAIL
			,PASSWORD
			,IMAGE
			)values(1
			, 'name user1'
			, 'username user1'
			, 'email user1'
			, 'password user1'
			, 'image user1'
			);
			
INSERT INTO APP_USER 	( id
			,NAME
			,USERNAME
			,EMAIL
			,PASSWORD
			,IMAGE
			)values(2
			, 'name user2'
			, 'username user2'
			, 'email user2'
			, 'password user2'
			, 'image user2'
			);
			
INSERT INTO APP_USER 	( id
			,NAME
			,USERNAME
			,EMAIL
			,PASSWORD
			,IMAGE
			)values(3
			, 'name user3'
			, 'username user3'
			, 'email user3'
			, 'password user3'
			, 'image user3'
			);
			
INSERT INTO APP_USER 	( id
			,NAME
			,USERNAME
			,EMAIL
			,PASSWORD
			,IMAGE
			)values(4
			, 'name user4'
			, 'username user4'
			, 'email user4'
			, 'password user4'
			, 'image user4'
			);
			
INSERT INTO APP_USER 	( id
			,NAME
			,USERNAME
			,EMAIL
			,PASSWORD
			,IMAGE
			)values(5
			, 'name user5'
			, 'username user5'
			, 'email user5'
			, 'password user5'
			, 'image user5'
			);
			

ALTER SEQUENCE hibernate_sequence RESTART WITH 9001;
TRUNCATE TABLE ROLE CASCADE;
INSERT INTO ROLE 	( id
			,AUTHORITY
			,DESCRIPTION
			)values(1
			, 'authority role1'
			, 'description role1'
			);
			
INSERT INTO ROLE 	( id
			,AUTHORITY
			,DESCRIPTION
			)values(2
			, 'authority role2'
			, 'description role2'
			);
			
INSERT INTO ROLE 	( id
			,AUTHORITY
			,DESCRIPTION
			)values(3
			, 'authority role3'
			, 'description role3'
			);
			
INSERT INTO ROLE 	( id
			,AUTHORITY
			,DESCRIPTION
			)values(4
			, 'authority role4'
			, 'description role4'
			);
			
INSERT INTO ROLE 	( id
			,AUTHORITY
			,DESCRIPTION
			)values(5
			, 'authority role5'
			, 'description role5'
			);
			

ALTER SEQUENCE hibernate_sequence RESTART WITH 10001;
TRUNCATE TABLE PERMISSION CASCADE;
INSERT INTO PERMISSION 	( id
			,NAME
			,DESCRIPTION
			,OPERATION
			,TAG_REMINDER
			)values(1
			, 'name permission1'
			, 'description permission1'
			, 'operation permission1'
			, 'tagReminder permission1'
			);
			
INSERT INTO PERMISSION 	( id
			,NAME
			,DESCRIPTION
			,OPERATION
			,TAG_REMINDER
			)values(2
			, 'name permission2'
			, 'description permission2'
			, 'operation permission2'
			, 'tagReminder permission2'
			);
			
INSERT INTO PERMISSION 	( id
			,NAME
			,DESCRIPTION
			,OPERATION
			,TAG_REMINDER
			)values(3
			, 'name permission3'
			, 'description permission3'
			, 'operation permission3'
			, 'tagReminder permission3'
			);
			
INSERT INTO PERMISSION 	( id
			,NAME
			,DESCRIPTION
			,OPERATION
			,TAG_REMINDER
			)values(4
			, 'name permission4'
			, 'description permission4'
			, 'operation permission4'
			, 'tagReminder permission4'
			);
			
INSERT INTO PERMISSION 	( id
			,NAME
			,DESCRIPTION
			,OPERATION
			,TAG_REMINDER
			)values(5
			, 'name permission5'
			, 'description permission5'
			, 'operation permission5'
			, 'tagReminder permission5'
			);
			

ALTER SEQUENCE hibernate_sequence RESTART WITH 11001;
TRUNCATE TABLE ACCESS_GROUP CASCADE;
INSERT INTO ACCESS_GROUP 	( id
			,NAME
			,DESCRIPTION
			)values(1
			, 'name group1'
			, 'description group1'
			);
			
INSERT INTO ACCESS_GROUP 	( id
			,NAME
			,DESCRIPTION
			)values(2
			, 'name group2'
			, 'description group2'
			);
			
INSERT INTO ACCESS_GROUP 	( id
			,NAME
			,DESCRIPTION
			)values(3
			, 'name group3'
			, 'description group3'
			);
			
INSERT INTO ACCESS_GROUP 	( id
			,NAME
			,DESCRIPTION
			)values(4
			, 'name group4'
			, 'description group4'
			);
			
INSERT INTO ACCESS_GROUP 	( id
			,NAME
			,DESCRIPTION
			)values(5
			, 'name group5'
			, 'description group5'
			);
			

ALTER SEQUENCE hibernate_sequence RESTART WITH 12001;
TRUNCATE TABLE ITEM CASCADE;
INSERT INTO ITEM 	( id
			,NAME
			,TYPE
			,IDENTIFIER
			,DESCRIPTION
			)values(1
			, 'name item1'
			, 'itemType item1'
			, 'identifier item1'
			, 'description item1'
			);
			
INSERT INTO ITEM 	( id
			,NAME
			,TYPE
			,IDENTIFIER
			,DESCRIPTION
			)values(2
			, 'name item2'
			, 'itemType item2'
			, 'identifier item2'
			, 'description item2'
			);
			
INSERT INTO ITEM 	( id
			,NAME
			,TYPE
			,IDENTIFIER
			,DESCRIPTION
			)values(3
			, 'name item3'
			, 'itemType item3'
			, 'identifier item3'
			, 'description item3'
			);
			
INSERT INTO ITEM 	( id
			,NAME
			,TYPE
			,IDENTIFIER
			,DESCRIPTION
			)values(4
			, 'name item4'
			, 'itemType item4'
			, 'identifier item4'
			, 'description item4'
			);
			
INSERT INTO ITEM 	( id
			,NAME
			,TYPE
			,IDENTIFIER
			,DESCRIPTION
			)values(5
			, 'name item5'
			, 'itemType item5'
			, 'identifier item5'
			, 'description item5'
			);
			


--Somente para a autenticação dos testes

 TRUNCATE TABLE user_role  CASCADE;
 DELETE FROM OWNER WHERE id = 101;
 INSERT INTO role( id, authority, description)  VALUES (101, 'ROLE_USER', 'Usuário do sistema');
 INSERT INTO owner (id, cnpj, corporate_name,  phone_number, logo, name) values (101,'','JSetup Developer', '997608620','','JSetup Developer');
-- Tabela de usuários
 INSERT INTO app_user(  id, enable, image, name, password, username, email, id_owner) VALUES (101, true, '', 'Usuário JSetup Comum', '$2a$10$teJrCEnsxNT49ZpXU7n22O27aCGbVYYe/RG6/XxdWPJbOLZubLIi2', 'jsetup', 'contato@jsetup.com', 101);
 --INSERT INTO role_user(role_id, user_id) values (2, 1);
 INSERT INTO user_role(id_role, id_user) values (101, 101);
