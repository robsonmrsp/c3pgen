 ALTER SEQUENCE hibernate_sequence RESTART WITH 10001;

 TRUNCATE TABLE owner CASCADE;
 TRUNCATE TABLE app_user CASCADE;
 TRUNCATE TABLE role CASCADE;
 TRUNCATE TABLE user_role CASCADE;

 INSERT INTO owner (id, cnpj, corporate_name,  phone_number, logo, name) values (101,'','JSetup Developer', '997608620','','JSetup Developer');

 INSERT INTO role( id, id_owner, authority, description)  VALUES (101, 101, 'ROLE_USER', 'Usuário do sistema');
 INSERT INTO app_user( id, id_owner, enable, image, name, password, username, email) VALUES (101, 101, true, '', 'Usuário JSetup Comum', '$2a$10$teJrCEnsxNT49ZpXU7n22O27aCGbVYYe/RG6/XxdWPJbOLZubLIi2', 'jsetup', 'contato@jsetup.com');
 INSERT INTO user_role(id_role, id_user) values (101, 101);

TRUNCATE TABLE EXIBICAO CASCADE;
INSERT INTO EXIBICAO 	( id, id_owner
			,DATA_HORA
			)values(1, 101
			, 'dataHora exibicao1'
			);
INSERT INTO EXIBICAO 	( id, id_owner
			,DATA_HORA
			)values(2, 101
			, 'dataHora exibicao2'
			);
INSERT INTO EXIBICAO 	( id, id_owner
			,DATA_HORA
			)values(3, 101
			, 'dataHora exibicao3'
			);
INSERT INTO EXIBICAO 	( id, id_owner
			,DATA_HORA
			)values(4, 101
			, 'dataHora exibicao4'
			);
INSERT INTO EXIBICAO 	( id, id_owner
			,DATA_HORA
			)values(5, 101
			, 'dataHora exibicao5'
			);
