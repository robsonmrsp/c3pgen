/** generated: 25/10/2017 23:05:47 **/
package br.com.netflics.integration.controller;

import static org.hamcrest.Matchers.containsString;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;

import br.com.netflics.core.model.Owner;
import br.com.netflics.core.persistence.pagination.PaginationParams;
import br.com.netflics.core.security.SpringSecurityUserContext;

import br.com.netflics.json.JsonDependente;
import br.com.netflics.model.Dependente;
import br.com.netflics.rs.DependenteController;
import br.com.netflics.service.DependenteService;

@RunWith(SpringRunner.class)
@WebMvcTest(DependenteController.class)
public class DependenteErrorMockTest {

	@Autowired
	private MockMvc mockMvc;

	@MockBean
	private DependenteService service;
	@MockBean
	private SpringSecurityUserContext context;

	@Test
	public void errorGetitingDependenteById() throws Exception {
		when(service.get(any(Integer.class), any(Owner.class))).thenThrow(new RuntimeException("Error Getting Dependente"));

		when(context.getOwner()).thenReturn(new Owner());

		this.mockMvc.perform(get("/rs/crud/dependentes/1")).andDo(print()).andExpect(status().is5xxServerError()).andExpect(content().string(containsString("Error Getting Dependente")));
	}

	@Test
	public void errorGetitingFilterEqualDependente() throws Exception {
		when(service.filter(any(PaginationParams.class), any(Owner.class), any(Boolean.class))).thenThrow(new RuntimeException("Error Getting Dependente"));

		when(context.getOwner()).thenReturn(new Owner());

		this.mockMvc.perform(get("/rs/crud/dependentes/filterEqual")).andDo(print()).andExpect(status().is5xxServerError()).andExpect(content().string(containsString("Error Getting Dependente")));
	}

	@Test
	public void errorGetitingFilterAlikeDependente() throws Exception {
		when(service.filter(any(PaginationParams.class), any(Owner.class), any(Boolean.class))).thenThrow(new RuntimeException("Error Getting Dependente"));

		when(context.getOwner()).thenReturn(new Owner());

		this.mockMvc.perform(get("/rs/crud/dependentes/filterAlike")).andDo(print()).andExpect(status().is5xxServerError()).andExpect(content().string(containsString("Error Getting Dependente")));
	}

	@Test
	public void errorGetitingAllDependente() throws Exception {
		when(service.all(any(Owner.class))).thenThrow(new RuntimeException("Error Getting Dependente"));

		when(context.getOwner()).thenReturn(new Owner());

		this.mockMvc.perform(get("/rs/crud/dependentes/all")).andDo(print()).andExpect(status().is5xxServerError()).andExpect(content().string(containsString("Error Getting Dependente")));
	}

	@Test
	public void errorGetitingAllPagerDependente() throws Exception {
		when(service.all(any(PaginationParams.class),any(Owner.class))).thenThrow(new RuntimeException("Error Getting Dependente"));

		when(context.getOwner()).thenReturn(new Owner());

		this.mockMvc.perform(get("/rs/crud/dependentes")).andDo(print()).andExpect(status().is5xxServerError()).andExpect(content().string(containsString("Error Getting Dependente")));
	}

	@Test
	public void errorPostitingDependente() throws Exception {
		when(service.save(any(Dependente.class))).thenThrow(new RuntimeException("Error creating Dependente"));
		when(context.getOwner()).thenReturn(new Owner());
		this.mockMvc.perform(post("/rs/crud/dependentes").contentType(MediaType.APPLICATION_JSON).content("{}")).andDo(print()).andExpect(status().is5xxServerError()).andExpect(content().string(containsString("Error creating Dependente")));
	}
	
	@Test
	public void errorUpdatingDependente() throws Exception {
		when(service.update(any(Dependente.class))).thenThrow(new RuntimeException("Error updating Dependente"));

		when(context.getOwner()).thenReturn(new Owner());

		this.mockMvc.perform(put("/rs/crud/dependentes/1").contentType(MediaType.APPLICATION_JSON).content("{}")).andDo(print()).andExpect(status().is5xxServerError()).andExpect(content().string(containsString("Error updating Dependente")));
	}

	@Test
	public void errorDeletingDependente() throws Exception {
		when(service.delete(any(Integer.class))).thenThrow(new RuntimeException("Error removing Dependente"));

		when(context.getOwner()).thenReturn(new Owner());

		this.mockMvc.perform(delete("/rs/crud/dependentes/1")).andDo(print()).andExpect(status().is5xxServerError()).andExpect(content().string(containsString("Error removing Dependente")));
	}

}