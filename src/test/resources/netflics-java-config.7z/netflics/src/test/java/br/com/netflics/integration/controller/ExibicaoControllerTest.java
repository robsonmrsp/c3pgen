/** generated: 25/10/2017 23:05:47 **/
package br.com.netflics.integration.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.function.Consumer;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.util.UriComponentsBuilder;

import br.com.netflics.core.persistence.pagination.Pager;
import br.com.netflics.model.Exibicao;
import br.com.netflics.fixture.FixtureUtils;
import br.com.six2six.fixturefactory.Fixture;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Sql("classpath:init-data-Exibicao.sql")
public class ExibicaoControllerTest {

	@Autowired
	TestRestTemplate testRestTemplate;

	private static final String URL = "/rs/crud/exibicaos";

	@BeforeClass
	public static void setUp() {
		FixtureUtils.init();
	}

	@Before
	public void before() {
	}

	@Test
	public void testAddExibicao() throws Exception {

		Exibicao exibicao = Fixture.from(Exibicao.class).gimme("novo");
		TestRestTemplate withBasicAuth = testRestTemplate.withBasicAuth("jsetup", "123456");

		ResponseEntity<Exibicao> responseEntity = withBasicAuth.postForEntity(URL, exibicao, Exibicao.class);

		HttpStatus status = responseEntity.getStatusCode();
		Exibicao resultExibicao = responseEntity.getBody();

		assertEquals("Incorrect Response Status: ", HttpStatus.OK, status);
		assertNotNull("A not null gender should be returned: ", resultExibicao);
		assertNotNull("A not null gender identifier should be returned:", resultExibicao.getId());
	}

	@Test
	public void testGetExibicao() throws Exception {

		TestRestTemplate withBasicAuth = testRestTemplate.withBasicAuth("jsetup", "123456");

		ResponseEntity<Exibicao> responseEntity = withBasicAuth.getForEntity(URL + "/{id}", Exibicao.class, new Integer(1));

		HttpStatus status = responseEntity.getStatusCode();
		Exibicao resultExibicao = responseEntity.getBody();

		assertEquals("Incorrect Response Status", HttpStatus.OK, status);
		assertNotNull("A not null gender should be returned: ", resultExibicao);
		assertEquals("A id gender == 1 must be returned: ", resultExibicao.getId(), new Integer(1));
	}

	@Test
	public void testGetPagerExibicao() throws Exception {

		TestRestTemplate withBasicAuth = testRestTemplate.withBasicAuth("jsetup", "123456");

		ResponseEntity<Pager> responseEntity = withBasicAuth.getForEntity(URL, Pager.class);

		HttpStatus status = responseEntity.getStatusCode();
		Pager<Exibicao> resultPagerExibicao = responseEntity.getBody();

		assertEquals("Incorrect Response Status", HttpStatus.OK, status);
		assertNotNull("A not null gender should be returned: ", resultPagerExibicao);
	}

	@Test
	public void testGetExibicaoNotExist() throws Exception {

		TestRestTemplate withBasicAuth = testRestTemplate.withBasicAuth("jsetup", "123456");

		ResponseEntity<Exibicao> responseEntity = withBasicAuth.getForEntity(URL + "/{id}", Exibicao.class, new Long(100));

		HttpStatus status = responseEntity.getStatusCode();
		Exibicao resultExibicao = responseEntity.getBody();

		assertEquals("Incorrect Response Status", HttpStatus.NO_CONTENT, status);
		assertNull(resultExibicao);
	}

	@Test
	public void testGetExibicaoFilterEqual() throws Exception {

		TestRestTemplate withBasicAuth = testRestTemplate.withBasicAuth("jsetup", "123456");

		ResponseEntity<Exibicao[]> responseEntity = withBasicAuth.getForEntity(URL + "/filterEqual?dataHora={dataHora}", Exibicao[].class,"dataHora exibicao1");
		Exibicao[] exibicaos = responseEntity.getBody();
		HttpStatus status = responseEntity.getStatusCode();

		assertEquals("Incorrect Response Status", HttpStatus.OK, status);

		assertTrue("A Array of Exibicao should be returned ", exibicaos.length > 0);

		Arrays.asList(exibicaos).forEach(new Consumer<Exibicao>() {
			@Override
			public void accept(Exibicao exibicao) {
				assertEquals("A not null Exibicao should be returned white the 'name' = 'dataHora exibicao1'", exibicao.getDataHora(), "dataHora exibicao1");
			}
		});
	}

	@Test
	public void testGetAllExibicao() throws Exception {

		TestRestTemplate withBasicAuth = testRestTemplate.withBasicAuth("jsetup", "123456");

		ResponseEntity<Exibicao[]> responseEntity = withBasicAuth.getForEntity(URL + "/all", Exibicao[].class);
		Exibicao[] exibicaos = responseEntity.getBody();
		HttpStatus status = responseEntity.getStatusCode();

		assertEquals("Incorrect Response Status", HttpStatus.OK, status);

		assertTrue("A Array of Exibicao should be returned ", exibicaos.length > 0);

	}

	@Test
	public void testDeleteExibicao() throws Exception {

		TestRestTemplate withBasicAuth = testRestTemplate.withBasicAuth("jsetup", "123456");

		ResponseEntity<Boolean> responseEntity = withBasicAuth.exchange(URL + "/{id}", HttpMethod.DELETE, null, Boolean.class, new Integer(1));

		Boolean result = responseEntity.getBody();
		HttpStatus status = responseEntity.getStatusCode();

		ResponseEntity<Exibicao> responseTesteDelete = withBasicAuth.getForEntity(URL + "/{id}", Exibicao.class, new Integer(1));

		HttpStatus responseTesteDeleteStatus = responseTesteDelete.getStatusCode();
		Exibicao resultExibicao = responseTesteDelete.getBody();

		assertEquals("Incorrect Response Status after delete the exibicao id = 1", HttpStatus.NO_CONTENT, responseTesteDeleteStatus);
		assertNull(resultExibicao);

		assertEquals("Incorrect Response Status", HttpStatus.OK, status);
		assertTrue("A Boolean.TRUE should be returned ", result);

	}

	@Test
	public void testGetExibicaoFilterALike() throws Exception {

		TestRestTemplate withBasicAuth = testRestTemplate.withBasicAuth("jsetup", "123456");

		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(URL + "/filterAlike").queryParam("dataHora", "exibicao");

		String uriString = builder.toUriString();
		ResponseEntity<Exibicao[]> responseEntity = withBasicAuth.getForEntity(uriString, Exibicao[].class);
		Exibicao[] exibicaos = responseEntity.getBody();
		HttpStatus status = responseEntity.getStatusCode();

		assertEquals("Incorrect Response Status", HttpStatus.OK, status);

		assertTrue("A Array of Exibicao should be returned ", exibicaos.length > 0);

		Arrays.asList(exibicaos).forEach(new Consumer<Exibicao>() {
			@Override
			public void accept(Exibicao exibicao) {
				assertTrue("A not null Exibicao should be returned white the 'name' like 'exibicao'", exibicao.getDataHora().contains("exibicao"));
			}
		});
	}
}

// generated by JSetup v0.95 : at 18/10/2017 08:40:58
//generated by JSetup v0.95 :  at 25/10/2017 23:05:47