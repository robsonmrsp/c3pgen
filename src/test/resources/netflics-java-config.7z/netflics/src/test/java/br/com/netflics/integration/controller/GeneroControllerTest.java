/** generated: 25/10/2017 23:05:47 **/
package br.com.netflics.integration.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.Arrays;
import java.util.function.Consumer;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.jdbc.Sql;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.util.UriComponentsBuilder;

import br.com.netflics.core.persistence.pagination.Pager;
import br.com.netflics.model.Genero;
import br.com.netflics.fixture.FixtureUtils;
import br.com.six2six.fixturefactory.Fixture;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = WebEnvironment.RANDOM_PORT)
@Sql("classpath:init-data-Genero.sql")
public class GeneroControllerTest {

	@Autowired
	TestRestTemplate testRestTemplate;

	private static final String URL = "/rs/crud/generos";

	@BeforeClass
	public static void setUp() {
		FixtureUtils.init();
	}

	@Before
	public void before() {
	}

	@Test
	public void testAddGenero() throws Exception {

		Genero genero = Fixture.from(Genero.class).gimme("novo");
		TestRestTemplate withBasicAuth = testRestTemplate.withBasicAuth("jsetup", "123456");

		ResponseEntity<Genero> responseEntity = withBasicAuth.postForEntity(URL, genero, Genero.class);

		HttpStatus status = responseEntity.getStatusCode();
		Genero resultGenero = responseEntity.getBody();

		assertEquals("Incorrect Response Status: ", HttpStatus.OK, status);
		assertNotNull("A not null gender should be returned: ", resultGenero);
		assertNotNull("A not null gender identifier should be returned:", resultGenero.getId());
	}

	@Test
	public void testGetGenero() throws Exception {

		TestRestTemplate withBasicAuth = testRestTemplate.withBasicAuth("jsetup", "123456");

		ResponseEntity<Genero> responseEntity = withBasicAuth.getForEntity(URL + "/{id}", Genero.class, new Integer(1));

		HttpStatus status = responseEntity.getStatusCode();
		Genero resultGenero = responseEntity.getBody();

		assertEquals("Incorrect Response Status", HttpStatus.OK, status);
		assertNotNull("A not null gender should be returned: ", resultGenero);
		assertEquals("A id gender == 1 must be returned: ", resultGenero.getId(), new Integer(1));
	}

	@Test
	public void testGetPagerGenero() throws Exception {

		TestRestTemplate withBasicAuth = testRestTemplate.withBasicAuth("jsetup", "123456");

		ResponseEntity<Pager> responseEntity = withBasicAuth.getForEntity(URL, Pager.class);

		HttpStatus status = responseEntity.getStatusCode();
		Pager<Genero> resultPagerGenero = responseEntity.getBody();

		assertEquals("Incorrect Response Status", HttpStatus.OK, status);
		assertNotNull("A not null gender should be returned: ", resultPagerGenero);
	}

	@Test
	public void testGetGeneroNotExist() throws Exception {

		TestRestTemplate withBasicAuth = testRestTemplate.withBasicAuth("jsetup", "123456");

		ResponseEntity<Genero> responseEntity = withBasicAuth.getForEntity(URL + "/{id}", Genero.class, new Long(100));

		HttpStatus status = responseEntity.getStatusCode();
		Genero resultGenero = responseEntity.getBody();

		assertEquals("Incorrect Response Status", HttpStatus.NO_CONTENT, status);
		assertNull(resultGenero);
	}

	@Test
	public void testGetGeneroFilterEqual() throws Exception {

		TestRestTemplate withBasicAuth = testRestTemplate.withBasicAuth("jsetup", "123456");

		ResponseEntity<Genero[]> responseEntity = withBasicAuth.getForEntity(URL + "/filterEqual?nome={nome}", Genero[].class,"nome genero1");
		Genero[] generos = responseEntity.getBody();
		HttpStatus status = responseEntity.getStatusCode();

		assertEquals("Incorrect Response Status", HttpStatus.OK, status);

		assertTrue("A Array of Genero should be returned ", generos.length > 0);

		Arrays.asList(generos).forEach(new Consumer<Genero>() {
			@Override
			public void accept(Genero genero) {
				assertEquals("A not null Genero should be returned white the 'name' = 'nome genero1'", genero.getNome(), "nome genero1");
			}
		});
	}

	@Test
	public void testGetAllGenero() throws Exception {

		TestRestTemplate withBasicAuth = testRestTemplate.withBasicAuth("jsetup", "123456");

		ResponseEntity<Genero[]> responseEntity = withBasicAuth.getForEntity(URL + "/all", Genero[].class);
		Genero[] generos = responseEntity.getBody();
		HttpStatus status = responseEntity.getStatusCode();

		assertEquals("Incorrect Response Status", HttpStatus.OK, status);

		assertTrue("A Array of Genero should be returned ", generos.length > 0);

	}

	@Test
	public void testDeleteGenero() throws Exception {

		TestRestTemplate withBasicAuth = testRestTemplate.withBasicAuth("jsetup", "123456");

		ResponseEntity<Boolean> responseEntity = withBasicAuth.exchange(URL + "/{id}", HttpMethod.DELETE, null, Boolean.class, new Integer(1));

		Boolean result = responseEntity.getBody();
		HttpStatus status = responseEntity.getStatusCode();

		ResponseEntity<Genero> responseTesteDelete = withBasicAuth.getForEntity(URL + "/{id}", Genero.class, new Integer(1));

		HttpStatus responseTesteDeleteStatus = responseTesteDelete.getStatusCode();
		Genero resultGenero = responseTesteDelete.getBody();

		assertEquals("Incorrect Response Status after delete the genero id = 1", HttpStatus.NO_CONTENT, responseTesteDeleteStatus);
		assertNull(resultGenero);

		assertEquals("Incorrect Response Status", HttpStatus.OK, status);
		assertTrue("A Boolean.TRUE should be returned ", result);

	}

	@Test
	public void testGetGeneroFilterALike() throws Exception {

		TestRestTemplate withBasicAuth = testRestTemplate.withBasicAuth("jsetup", "123456");

		UriComponentsBuilder builder = UriComponentsBuilder.fromUriString(URL + "/filterAlike").queryParam("nome", "genero");

		String uriString = builder.toUriString();
		ResponseEntity<Genero[]> responseEntity = withBasicAuth.getForEntity(uriString, Genero[].class);
		Genero[] generos = responseEntity.getBody();
		HttpStatus status = responseEntity.getStatusCode();

		assertEquals("Incorrect Response Status", HttpStatus.OK, status);

		assertTrue("A Array of Genero should be returned ", generos.length > 0);

		Arrays.asList(generos).forEach(new Consumer<Genero>() {
			@Override
			public void accept(Genero genero) {
				assertTrue("A not null Genero should be returned white the 'name' like 'genero'", genero.getNome().contains("genero"));
			}
		});
	}
}

// generated by JSetup v0.95 : at 18/10/2017 08:40:58
//generated by JSetup v0.95 :  at 25/10/2017 23:05:47