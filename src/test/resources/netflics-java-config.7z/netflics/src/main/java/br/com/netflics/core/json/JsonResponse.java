package br.com.netflics.core.json;

public class JsonResponse {

}
